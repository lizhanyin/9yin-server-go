-- 0016_role_item_random_props_20261108.sql
-- 娃娃/宝物随机属性持久化（第一批落地，盘点文档
-- docs/镇派兵器与娃娃宝物随机属性.md §3.5/§3.6）：
-- 随机属性行按物品实例 uid 存快照，登录/穿戴时经视图 record 下发
-- （RandomPropRec 400 / RandomSkillRec 401，官服 0x11 flag=1 方言）。

CREATE TABLE IF NOT EXISTS `role_item_random_props` (
  `role_id` bigint unsigned NOT NULL,
  `uid` varchar(32) NOT NULL,
  `config_id` varchar(64) NOT NULL,
  `kind` tinyint NOT NULL DEFAULT 0,
  `prop_rows` json NULL,
  `skill_rows` json NULL,
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`, `uid`),
  CONSTRAINT `fk_random_props_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
