-- 0019_role_timed_buffs_20261110.sql
-- 限时 buff 域（timed_buffs.go）：超长时限增益的存储与到期记录。
--   role_timed_buffs  条目快照（[{configId,level,category,expiresAt
--                  RFC3339 UTC}]，结构对齐 role_currency 基线快照表）。
-- 服务器运行时不做 DDL（缺表降级会话态）；本脚本幂等可重放。

CREATE TABLE IF NOT EXISTS `role_timed_buffs` (
  `role_id` bigint unsigned NOT NULL,
  `snapshot` json NOT NULL,
  `version` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_timed_buffs_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
