-- 0014_add_role_currency_and_titles_20261107.sql
-- P2 商店/称号域（msg70/71 商店购销、msg295 称号）：
--   role_currency  碎银快照（fork 二进制 {Silver json:"silver"} 同形，
--                  结构对齐 role_faculty/role_meridians 基线快照表）。
--   role_titles    称号拥有+佩戴位（Java PanelDataStore 同表形：
--                  role_id+title_id 复合 PK、title_type、is_worn、obtained_unix）。
-- 服务器运行时不做 DDL（缺表降级会话态）；本脚本幂等可重放。

CREATE TABLE IF NOT EXISTS `role_currency` (
  `role_id` bigint unsigned NOT NULL,
  `snapshot` json NOT NULL,
  `version` bigint unsigned NOT NULL DEFAULT '1',
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  CONSTRAINT `fk_currency_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `role_titles` (
  `role_id` bigint unsigned NOT NULL,
  `title_id` int NOT NULL,
  `title_type` int NOT NULL DEFAULT '0',
  `is_worn` tinyint NOT NULL DEFAULT '0',
  `obtained_unix` bigint unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`role_id`, `title_id`),
  CONSTRAINT `fk_titles_role` FOREIGN KEY (`role_id`) REFERENCES `roles` (`role_id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
