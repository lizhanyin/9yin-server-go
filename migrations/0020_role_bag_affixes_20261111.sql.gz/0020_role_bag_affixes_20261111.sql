-- 0020_role_bag_affixes_20261111.sql
-- 装备/宝物/娃娃洗炼二期：role_bag_items 加 affixes 列（背包装备的词条
-- 落档通道，role_equip_items.affixes 0003 同义）。武器重铸（C2S 933-938）
-- 与武器强化（C2S 861）二期扩展背包装备（VIEWPORT_EQUIP_TOOL=121 页）：
-- 第一期只支持穿戴中武器即因背包行无此列。
-- 语义：JSON 数组 [{"pack_rec":0,"prop_built":词条,"kind":1|2}]（镇派
-- 兵器/重铸同形态）；读取侧解为 PropBuilt@1954 串随 ViewAdd 下发。
-- 读写降级（服务器运行时不做 DDL）：旧库无列时 insertBagItem 剥列重试、
-- bagItems 降级重查、updateBagAffixes 静默跳过——内存与帧仍权威。
-- 旧行 NULL 读取按空词条处理；重铸/强化写入时才产生非空值，无需回填。
-- 本脚本幂等可重放。

SET @bag_col = (SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'role_bag_items'
    AND COLUMN_NAME = 'affixes');
SET @bag_ddl = IF(@bag_col = 0,
  'ALTER TABLE `role_bag_items` ADD COLUMN `affixes` JSON NULL DEFAULT NULL AFTER `seq`',
  'SELECT 1');
PREPARE stmt FROM @bag_ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
