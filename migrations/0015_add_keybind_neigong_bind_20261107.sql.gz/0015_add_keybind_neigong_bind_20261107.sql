-- 0015_add_keybind_neigong_bind_20261107.sql
-- 内功栏绑定持久化：role_keybinds.neigong_bind（键位域同表扩展，0008 同款）。
-- 协议：C2S 199 CLIENT_CUSTOMMSG_NEIGONGBIND（custom_update_ng_bind(info)，
-- form_main_shortcut.lua 内功栏绑定框 on_btn_bind_click → update_to_srv），
-- info = "v1;…;v25;"——内功栏 25 格（grid_shortcut_3 三页各 5 格 +
-- grid_shortcut_8 十格，G_NG_GRID_COUNT=25）各自绑定的武器快捷栏序号（0=未绑定）。
-- 玩家属性 NeiGongBind（0x09 表索引 201，type7）下发恢复：客户端主窗体打开时
-- get_svr_ng_bind 整串快照，服务端不回存档则重登全零——表现为「内功栏放置
-- 武器/内功绑定的快捷栏序号没有存储」。
-- 幂等：information_schema 探测列存在才 ALTER（MySQL 8.0 无 ADD COLUMN IF NOT EXISTS）。

SET @col_exists = (SELECT COUNT(*) FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'role_keybinds'
    AND COLUMN_NAME = 'neigong_bind');
SET @ddl = IF(@col_exists = 0,
  'ALTER TABLE `role_keybinds` ADD COLUMN `neigong_bind` varchar(128) NULL DEFAULT NULL AFTER `operate_mode`',
  'SELECT 1');
PREPARE stmt FROM @ddl;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;
